LOCADORA DE CARROS - PROJETO PHP ORGANIZADO

Esta versão abre no navegador usando PHP e MySQL. Todos os arquivos de programação possuem extensão .php. O HTML das páginas é gerado pelos próprios arquivos PHP; não há arquivos .html separados.

COMO INSTALAR:
1. Extraia a pasta Locadora_Carros_PHP_Organizado para C:\xampp\htdocs.
2. Abra o XAMPP e inicie Apache e MySQL.
3. Acesse http://localhost/phpmyadmin
4. Entre na aba Importar e selecione o arquivo banco.sql que está nesta pasta.
5. Clique em Executar.
6. Acesse http://localhost/Locadora_Carros_PHP_Organizado/

ESTRUTURA:
index.php                  Menu principal do sistema
config/conexao.php         Conexão com o banco MySQL
config/funcoes.php         Funções comuns e visual padrão das páginas
clientes/                  CRUD de clientes
carros/                    CRUD de veículos
locacoes/                  CRUD de locações
banco.sql                  Criação do banco e das tabelas

EXPLICAÇÃO DO CRUD:
C - Create (INSERT): cadastrar dados.
R - Read (SELECT): consultar/listar dados.
U - Update (UPDATE): editar dados.
D - Delete (DELETE): excluir dados.

ORGANIZAÇÃO DO CÓDIGO:
- Cada módulo tem uma pasta própria.
- Cada operação fica em um arquivo PHP separado.
- A conexão com o banco está centralizada em config/conexao.php.
- As funções repetidas de página estão em config/funcoes.php.
- Os comandos SQL com dados enviados pelos formulários usam prepared statements.

OBSERVAÇÃO:
Não abra os arquivos PHP com duplo clique. Use o endereço localhost no navegador para que o Apache execute o PHP.
